SBL 1.0 resolved page rendering package
Render target: CH6-P003
Entry file: CH6-P003.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zora-Nyas-world-map.png
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt
  Assets/Zora-Nyas-writing-systems-sheet.png
  Assets/Zora-cultural-development-specification.txt
  Assets/Nyas-cultural-development-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
