SBL 1.0 resolved page rendering package
Render target: CH6-P031
Entry file: CH6-P031.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna-expression-sheet.png
  Assets/WOA-canonical-production-specification.txt
  Assets/Nyssara-character-sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Light-Healing-and-Illusion-Training-Technical-Sheet.png
  Assets/WOA-production-sheet-plus-map.png
  Assets/WOA-observation-field-states-sheet.png
  Assets/Nyssara-expression-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Zorna-canonical-character-specification.txt
  Assets/WOA-time-compression-display-specification.txt
  Assets/Nyssara-canonical-character-specification.txt
  Assets/WOA-production-sheet.png
  Assets/Zorna-character-sheet.png
  Assets/Terra-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
