SBL 1.0 resolved page rendering package
Render target: CH6-P025
Entry file: CH6-P025.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Light-Healing-and-Illusion-Training-Technical-Sheet.png
  Assets/Zora-cultural-development-specification.txt
  Assets/Nyas-cultural-development-specification.txt
  Assets/Zoran-mana-crystals-production-sheet.png
  Assets/Zora-Nyas-writing-systems-sheet.png
  Assets/Zora-mana-effects-sheet.png
  Assets/Zora-Nyas-world-map.png
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
